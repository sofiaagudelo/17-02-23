console.log ("entramos");
var items = document.getElementsByClassName("item");
var cantidad = items.length; 
console.log(cantidad);

console.log ("cantidad de listas" + cantidad);
var div= document.createElement ("div");
div;

div.innerText= "aprendiendo javaScript";
var divuno = document.getElementById("uno");
divuno.appendChild(div);
var lista = document.getElementById("lista");
var hijo = document.createElement("li");
hijo.innerText = "li nuevo";
lista.appendChild(hijo);

document.getElementById("tres").style.color= "red";
document.getElementById("lista").style.color= "green";

document.body.style.backgroundColor =  "blue";


var divdos= document.createElement ("div");
divdos.style.backgroundcolor="blue";
var parrafo = document.createElement ("p");
parrafo.innerText= "Me gustas cuando callas porque estás como ausente, y me oyes desde lejos y mi voz no te toca Parece que los ojos se te hubieran voladoy parece que un beso te cerrara la boca.";
var lista2 = document.createElement("ul");
var contenido = document.createElement ("li");
contenido.innerText = "contenido";
lista2.appendChild(contenido);
divdos.appendChild(parrafo);
divdos.appendChild(lista2);
