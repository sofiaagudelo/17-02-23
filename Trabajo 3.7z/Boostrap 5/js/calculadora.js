let valor1 = document.getElementById("vi");
let contenedor = document.getElementById("calculadora")
valor1.innerHTML = document = "hola";

let resultado = document.getElementById